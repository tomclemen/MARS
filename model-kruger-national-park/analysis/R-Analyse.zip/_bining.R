d <- ggplot() + xlim(4, 10) + ylim(4, 10)
d + geom_bin2d()

# Or by specifying the width of the bins
d + geom_count(data=diamonds, aes(x, y,color = ..n.., size = ..n..), binwidth = c(0.5,0.5))  +
  guides(color = 'legend')

https://www.rdocumentation.org/packages/ggplot2/versions/2.2.1/topics/geom_bin2d
https://stackoverflow.com/questions/45883097/color-points-by-their-occurance-count-in-ggplot2-geom-count/45883383