library(ncdf4)
library(raster)
library(maptools)
library(rgdal)
data("wrld_simpl")
library(plyr)
library(RColorBrewer)
#library(ggplot2)
#library(ggspatial)

l <- readOGR("gis_raster_border/gis_raster_border.shp")

graphics.off()
pdf( file="knp_adgvm_biomasses.pdf", height=3.7, width=10 )

par( mfrow=c(1,4), mar=c(3,3,1,4), oma=c(0,2,2,1) )

scen <- c(45,45,85,85) #
year <- c(2031,2018,2000,2094)
snam <- c("RCP 4.5", "RCP 4.5", "RCP 8.5", "RCP 8.5")

for ( i in 1:length(scen) )
{
  #  d     <- read.table(paste("veg_knp_withfire_RCP", scen[i], ".dat",sep=""))
  d     <- read.table(paste("veg_knp_wifi_RCP", scen[i], ".dat",sep=""))
  xx <- sort(unique(d[,1]))
  yy <- rev(sort(unique(d[,2])))
  
  aglb1 <- matrix( NA, length(yy), length(xx) )  # above ground tree biomass
  mx    <- matrix( NA, length(yy), length(xx) )
  my    <- matrix( NA, length(yy), length(xx) )
  
  for ( x in 1:length(xx) )
  {
    for ( y in 1:length(yy) )
    {
      b <- subset( d, d[,1]==xx[x] & d[,2]==yy[y] & d[,3]==year[i] )
      h <- mean(b[,4], na.rm=T)   ### correct column?
      
      aglb1[y,x] <- h
      mx[y,x]   <- xx[x]
      my[y,x]   <- yy[y]
    }
  }
  
  lonlat     <- expand.grid(xx,yy)
  
  xyz_aglb1   <- data.frame(cbind(lonlat,as.vector(t(aglb1))))
  xyz_aglb1_r <- rasterFromXYZ(xyz_aglb1, res=c(0.5,0.5), crs=NA, digits=5)
  
  # ---------------------------------------------------------------------
  # --- Plots -----------------------------------------------------------
  # ---------------------------------------------------------------------
  
  #data_json <- readOGR(dsn = "RCP45-18-VegNew-3-3500.geojson", layer = "OGRGeoJSON")
  
  bm_brk   <- 0:10
  bm_col_t <- brewer.pal(9,"Greens")
  bm_col   <- colorRampPalette(bm_col_t)( 10 ) 
  
  plot(xyz_aglb1_r, col=bm_col, breaks=bm_brk, main=paste(snam[i], ", ", year[i], sep=""), 
       interpolate=F, useRaster=F, asp=1, legend=F )
  plot(xyz_aglb1_r, legend.only=TRUE, col=bm_col, breaks=bm_brk, legend.width=1, legend.args=list(text="  t/ha\n", side=3) )
  #plot(data_json, add=T)
  plot(l, add=T)
  
}

graphics.off()
